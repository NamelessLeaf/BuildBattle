# BuildBattle
build battle for pocketmine
Note: I only tested this plugin once I still dont yet if it is good. If you catch any errors then please let me know!!! 

## Features

- Simple Setup 
- Waiting Lobby Included
- Custom Voting Messages
- More than 10+ Builds
- 1st 2nd and 3rd and percentage.
# Whats Coming Soon
- Score Boards [NEXT UPDATE]
- Voting for what build you want to build [COMING SOON]
- Super Votes for VIP [COMING SOON]
- Effects [NEXT UPDATE]

You are free to make suggestions to this plugin

## Setup

- To make a new arena do /bb <arena> 
- We recommend using this map https://www.mediafire.com/file/vkki8vsaf9d54kf/BuildBattle-Map.zip/file.
- Tap All The Middle Parts of the arena (16 Spawns) 
- After you tap 16 Spawns you put the waiting lobby and you are done
  
## Installation:
Download latest release or sucess build
Upload it to your server folder /plugins/
Restart the server

## Credits 

I have seen most build battle plugins and i decided to make one mainly for my server WC Server and made a Build Battle plugin using some code from Good Coders.

